class Notas {
    constructor(ra, nome, nota1, nota2, nota3, nota4, posicaoNaLista ) {
        this.ra = ra;
        this.nome = nome;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
        this.nota4 = nota4;


        this.posicaoNaLista = posicaoNaLista;
    }
}